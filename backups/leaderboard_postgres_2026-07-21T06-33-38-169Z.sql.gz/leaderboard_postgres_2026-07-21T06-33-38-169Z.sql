--
-- PostgreSQL database dump
--

\restrict 3P6dX0s6hAzdMFRFsNHdzyIdj9VY6KpxqYhsapEHfzuIudSFmrujuaH0dY1U4kO

-- Dumped from database version 16.14 (Ubuntu 16.14-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.14 (Ubuntu 16.14-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict 3P6dX0s6hAzdMFRFsNHdzyIdj9VY6KpxqYhsapEHfzuIudSFmrujuaH0dY1U4kO

